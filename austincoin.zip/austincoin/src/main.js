const {Blockchain, Transaction} = require('./blockchain');
const EC = require('elliptic').ec;
const ec = new EC('secp256k1');

const myKey = ec.keyFromPrivate('1fb3904e4975c1cff40ad621b62d69fdce9c86331eb44f2a286307f65b7f6fb6')
const myWalletAddress = myKey.getPublic('hex');

let austinCoin = new Blockchain();

const tx1 = new Transaction(myWalletAddress, 'public key goes here', 10);
tx1.signTransaction(myKey);
austinCoin.addTransaction(tx1);



console.log('\nStarting the miner...');
austinCoin.minePendingTransactions(myWalletAddress);

console.log('\nBalance of user is ', austinCoin.getBalanceOfAddress(myWalletAddress));